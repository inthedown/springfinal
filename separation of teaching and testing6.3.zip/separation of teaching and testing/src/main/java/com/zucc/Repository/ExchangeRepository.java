package com.zucc.Repository;

import com.zucc.Entity.Exchange_paper;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ExchangeRepository extends JpaRepository<Exchange_paper,Integer> {
    @Transactional
    @Modifying
    @Query(value = "update Exchange_paper set grade =:grade where sno_corrected=:sno",nativeQuery = true)
    void updateGrade(float grade,String sno);

    @Query(value = "from Exchange_paper where sno =:sno")
    List<Exchange_paper> searchGrade(String sno);
    @Query(value = "select grade from Exchange_paper where sno_corrected=:stu_id",nativeQuery = true)
    List<Float> findGrade(String stu_id);

    @Transactional
    @Modifying
    @Query(value = "delete from Exchange_paper where exam_id=:exam_id",nativeQuery = true)
    void deleteByExamId(int exam_id);
}
