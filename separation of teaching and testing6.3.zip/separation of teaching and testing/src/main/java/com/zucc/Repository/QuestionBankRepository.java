package com.zucc.Repository;

import com.zucc.Entity.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface QuestionBankRepository extends JpaRepository<Question,Integer> {
    @Query(value="select * from question where course_name=:courseName",nativeQuery = true)
    List<Question> searchQuestion(String courseName);
    @Query(value = "select score from question where id=:id",nativeQuery = true)
    Float findScore(int id);
    @Query(value = "select a.context from selection a,answer b where a.id = b.selection_id and a.question_id =:id",nativeQuery = true)
    String findRightAnswer(int id);
}
