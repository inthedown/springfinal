package com.zucc.Repository;

import com.zucc.Entity.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ExamRepository extends JpaRepository<Exam,Integer> {
    @Query(value="SELECT * from exam where teacher_name in (select tea_name from teacher where t_id=:id)",nativeQuery = true)
    List<Exam> findAllByTeacherId(int id);
    @Query(value="SELECT * from exam where id in (select exam_id from examinee where student_id=:id)",nativeQuery = true)
    List<Exam> findAllByStudentId(int id);
    @Query(value = "select ispeer from exam where id=:exam_id",nativeQuery = true)
    String findInfo(int exam_id);

    @Transactional
    @Modifying
    @Query(value = "delete from exam where id=:exam_id",nativeQuery = true)
    void deleteByExamId(int exam_id);
}
