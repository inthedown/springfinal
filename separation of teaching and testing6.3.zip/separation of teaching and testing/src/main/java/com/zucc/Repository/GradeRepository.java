package com.zucc.Repository;

import com.zucc.Entity.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface GradeRepository extends JpaRepository<Grade,Integer> {
    @Query(value = "select * from grade where sno=:sno and exam_id=:id",nativeQuery = true)
    List<Grade> searchStudentGrade(String sno, int id);
    @Transactional
    @Modifying
    @Query(value = "delete from grade where exam_id=:exam_id",nativeQuery = true)
    void deleteByExamId(int exam_id);
}
