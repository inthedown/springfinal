package com.zucc.Repository;

import com.zucc.Entity.Examinee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ExamineeRepository extends JpaRepository<Examinee,Integer> {
    @Query(value="select student_id from examinee where exam_id=:id",nativeQuery = true)
    List<Integer> findByExamId(int id);
    @Query(value="select count_num from examinee where student_id=:sno",nativeQuery = true)
    Integer findCountBySno(int sno);
    @Query(value="select student_id from examinee where exam_id=:id and student_id !=:sno",nativeQuery = true)
    List<Integer> findAllByExamId(int id,int sno);
    @Transactional
    @Modifying
    @Query(value = "update examinee set count_num = :count where student_id =:sno",nativeQuery = true)
    void updateCheck(int count, int sno);
    @Transactional
    @Modifying
    @Query(value = "delete from examinee where exam_id=:exam_id",nativeQuery = true)
    void deleteByExamId(int exam_id);
}
