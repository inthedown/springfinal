package com.zucc.Repository;

import com.zucc.Entity.FinishCondition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface FinishRepository extends JpaRepository<FinishCondition,Integer> {
    @Transactional
    @Modifying
    @Query(value = "insert into finish(exam_id,sno,status) values(?,?,?)",nativeQuery = true)
    void saveAll(int exam_id,String sno,String status);

    @Transactional
    @Modifying
    @Query(value = "delete from finish where exam_id=:exam_id",nativeQuery = true)
    void deleteByExamId(int exam_id);
}
