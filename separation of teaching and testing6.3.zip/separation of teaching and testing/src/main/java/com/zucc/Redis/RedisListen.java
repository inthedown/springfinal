package com.zucc.Redis;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;


@Component
@Slf4j
public class RedisListen implements MessageListener {

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    @Override
    public void onMessage(Message message, byte[] pattern) {
        String expiredKey = message.toString();

        log.info("失效的redis是:"+expiredKey);
        RedisSerializer<?> serializer = redisTemplate.getValueSerializer();
        String channel = String.valueOf(serializer.deserialize(message.getChannel()));
        String body = String.valueOf(serializer.deserialize(message.getBody()));
        log.info("channel==="+channel+"-----------------"+"body === "+body);
        //key过期监听,在处理业务之前校验下自己业务的key和监听的key以及库号
        if("__keyevent@1__:expired".equals(channel) && body.indexOf("StatusTest") != -1){
            //log.info("进来了哈");
            //这里写需要处理的业务

            }else{String key=expiredKey.replace("Test","");
                log.info(key+"    aaaa  "+redisTemplate.opsForValue().get(key));
                if(!redisTemplate.opsForValue().get(key).equals("1")){
                    redisTemplate.opsForValue().set(expiredKey,"",6, TimeUnit.SECONDS);
                    String[] split = expiredKey.split("-");
                    String questionnaireId = split[2];
                    String stuId = split[4];
                    log.info(Arrays.toString(split));
                boolean a=redisTemplate.delete(key);
                log.info("删除结果"+a);
            }
        }

    }
}
