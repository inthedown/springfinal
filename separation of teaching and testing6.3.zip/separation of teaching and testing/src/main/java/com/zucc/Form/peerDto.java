package com.zucc.Form;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class peerDto implements Serializable {
    private String sno_corrected;
    private List<DetailDto> details;
}
