package com.zucc.Form;

import com.zucc.Entity.StudentSelect;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
@Data
public class StudentSelectDto implements Serializable {
    private int id;
    private int questionId;
    private List<Integer> selectionId;
    private String questionType;
    private List<String> answers;
}
