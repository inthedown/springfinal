package com.zucc.Form;

import lombok.Data;

import java.io.Serializable;

@Data
public class DetailDto implements Serializable {
    private int question_id;
    private float grades;
}
