package com.zucc.Form;

import com.zucc.Entity.StudentSelect;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class FinishDto implements Serializable {
    private int id;
    private String sno;//学号
    private int examId;//考试编号
    private List<StudentSelectDto> content;

}
