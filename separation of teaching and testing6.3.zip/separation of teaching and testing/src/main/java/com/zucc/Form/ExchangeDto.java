package com.zucc.Form;

import lombok.Data;

import java.io.Serializable;
import java.util.List;
import com.zucc.Form.peerDto;

@Data
public class ExchangeDto implements Serializable {
    private int id;
    private int exam_id;
    private String sno;
    private List<peerDto> detail;
}
