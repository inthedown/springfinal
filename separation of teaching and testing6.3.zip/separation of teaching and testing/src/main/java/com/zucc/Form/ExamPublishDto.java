package com.zucc.Form;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zucc.Entity.Exam;
import lombok.Data;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.sql.Timestamp;
import java.util.List;

@Data
public class ExamPublishDto {
    private final int id;
    private final String name;
    private final String status;
    private final String[] Examinees;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd hh:mm:ss",locale="zh", timezone="GMT+8")
    private final Timestamp startTime;
    private final String teacherName;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd hh:mm:ss",locale="zh", timezone="GMT+8")
    private final Timestamp endTime;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd hh:mm:ss",locale="zh", timezone="GMT+8")
    private final Timestamp limitCome;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd hh:mm:ss",locale="zh", timezone="GMT+8")
    private final Timestamp limitSubmit;
    private final List<QuestionDto> questions;
    private String isPeer;

    public Exam convert(ExamPublishDto dto){
        Exam aExam = new Exam();
        aExam.setId( dto.id);
        aExam.setName(dto.name);
        aExam.setStatus(dto.status);
        aExam.setStartTime(dto.startTime);
        aExam.setEndTime(dto.endTime);
        aExam.setTeacherName(dto.teacherName);
        aExam.setLimitCome(dto.limitCome);
        aExam.setLimitSubmit(dto.limitSubmit);
        aExam.setIsPeer(dto.isPeer);
        return aExam;
    }
}
