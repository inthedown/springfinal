package com.zucc.Form;

import lombok.Data;

import java.io.Serializable;

@Data
public class CorrectDto implements Serializable {
    private int id;
    private int examId;
    private int sno;
    private int questionId;
    private String answers;
    private String correctAnswers;
}
