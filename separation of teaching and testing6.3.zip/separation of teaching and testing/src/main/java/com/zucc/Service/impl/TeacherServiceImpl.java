package com.zucc.Service.impl;

import com.zucc.Entity.Teacher;
import com.zucc.Exception.EchoServiceException;
import com.zucc.Form.StudentDto;
import com.zucc.Form.TeacherDto;
import com.zucc.Repository.TeacherRepository;
import com.zucc.Service.TeacherService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class TeacherServiceImpl implements TeacherService {
    @Autowired
    private TeacherRepository teacherRepository;

    //todo 注册
    @Override
    public boolean register(TeacherDto teacherDto) throws EchoServiceException {
        Teacher ateacher = new Teacher();
        BeanUtils.copyProperties(teacherDto, ateacher);
        System.out.println("内容1："+ateacher);
        System.out.println("内容2："+teacherDto);
        String tno = teacherDto.getTno();
        String name = teacherDto.getName();
        String pwd = teacherDto.getPwd();
        System.out.println("课程"+tno);
        if(teacherRepository.searchPwd(tno)==null){
            ateacher.setTno(tno);
            ateacher.setName(name);
            ateacher.setPwd(pwd);
            teacherRepository.save(ateacher);
//            System.out.println("tno:"+tno);
//            System.out.println("name:"+name);
//            System.out.println("course:"+course);
//            teacherRepository.saveCourse(tno,name,course);
//            System.out.println("老师"+"suss");
            return true;
        }else {
            return  false;
        }

    }
    //todo 密码登录
    @Override
    public boolean login(TeacherDto teacherDto) throws EchoServiceException{
        String tno = teacherDto.getTno();
        String pwd = teacherDto.getPwd();
        if (teacherRepository.searchPwd(tno) != null) {
            if (teacherRepository.searchPwd(tno).equals(pwd)) return true;
            else return false;
        } else {
            return false;
        }
    }

    //todo 修改密码
    @Override
    public boolean modifyPwd(TeacherDto teacherDto) throws EchoServiceException{
        String tno = teacherDto.getTno();
        String pwd = teacherDto.getPwd();
        String new_pwd = teacherDto.getNew_pwd();
        if (teacherRepository.searchPwd(tno) != null) {
            if (teacherRepository.searchPwd(tno).equals(pwd)) {
                teacherRepository.changePwd(tno, new_pwd);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    //todo 删除
    @Override
    public boolean deleteTeacher(TeacherDto teacherDto) throws EchoServiceException{
        String tno = teacherDto.getTno();
        if (teacherRepository.searchPwd(tno)!= null) {
            teacherRepository.deleteByTno(tno);
            return true;
        } else {
            return false;
        }
    }

}
