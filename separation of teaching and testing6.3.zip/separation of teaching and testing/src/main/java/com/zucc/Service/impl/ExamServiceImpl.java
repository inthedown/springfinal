package com.zucc.Service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zucc.Entity.*;
import com.zucc.Form.*;
import com.zucc.Repository.*;
import com.zucc.Service.ExamService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Pattern;

@Service
public class ExamServiceImpl implements ExamService {
    @Autowired
    private ExamRepository examRepository;
    @Autowired
    private ExamineeRepository examineeRepository;
    @Autowired
    private ExamQuestionsRepository examQuestionsRepository;
    @Autowired
    private QuestionBankRepository questionBankRepository;
    @Autowired
    private SelectionRepository selectionRepository;
    @Autowired
    private AnswerRepository answerRepository;
    @Autowired
    private StudentSelectRepository studentSelectRepository;
    @Autowired
    private FinishRepository finishRepository;
    @Autowired
    private GradeRepository gradeRepository;
    @Autowired
    private ExchangeRepository exchangeRepository;
    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    private float grade_count = 0;

    @Override
    public Exam publish(ExamPublishDto examPublishDto) {
        //考卷插入
        Exam aExam = examPublishDto.convert(examPublishDto);
        System.out.println(aExam);
        Exam bExam = examRepository.save(aExam);
        String[] examinees = examPublishDto.getExaminees();
        //参考人员插入
        for (String examine : examinees) {
            if (Pattern.compile("^-?[1-9]\\d*$").matcher(examine).find()) {
                Examinee aExaminee = new Examinee();
                aExaminee.setExamId(bExam.getId());
                aExaminee.setStudentId(Integer.valueOf(examine));
                examineeRepository.save(aExaminee);
            }
        }
        redisTemplate.opsForValue().set("examId-"+aExam.getId()+"-start", String.valueOf(aExam.getStartTime()));
        redisTemplate.opsForValue().set("examId-"+aExam.getId()+"-limitIn",String.valueOf(aExam.getLimitCome()));

        //考题插入题库
        List<QuestionDto> questionDtoList = examPublishDto.getQuestions();
        questionDtoList.forEach(questionDto -> {
                    System.out.println(questionDto);
                    Question aquestion = new Question();
                    aquestion.setCourseName(questionDto.getCourseName());
                    aquestion.setTitle(questionDto.getTitle());
                    aquestion.setType(questionDto.getQuestionType());
                    Question bquestion = questionBankRepository.save(aquestion);
                    int questionId = bquestion.getId();
                    ExamQuestions aEQ = new ExamQuestions();
                    aEQ.setExamId(bExam.getId());
                    aEQ.setQuestionId(questionId);
                    examQuestionsRepository.save(aEQ);
                    String type = questionDto.getQuestionType();
                    if (type.equals("单选") || type.equals("填空") || type.equals("判断")) {
                        String[] selections = questionDto.getSelections();
                        String[] answers = questionDto.getAnswer();
                        for (String selection : selections) {
                            Selection aselection = new Selection();
                            aselection.setQuestionId(questionId);
                            aselection.setContext(selection);
                            Selection bselection = selectionRepository.save(aselection);
                            if (answers != null) {
                                if (selection.equals(answers[0])) {
                                    Answer aanswer = new Answer();
                                    aanswer.setQuestionId(questionId);
                                    aanswer.setSelectionId(bselection.getId());
                                    answerRepository.save(aanswer);
                                }
                            }

                        }
                    } else if (type.equals("多选")) {
                        String[] selections = questionDto.getSelections();
                        String[] answers = questionDto.getAnswer();
                        for (String selection : selections) {
                            Selection aselection = new Selection();
                            aselection.setQuestionId(questionId);
                            aselection.setContext(selection);
                            Selection bselection = selectionRepository.save(aselection);
                            for (String answer : answers) {
                                if (selection.equals(answer)) {
                                    Answer aanswer = new Answer();
                                    aanswer.setQuestionId(questionId);
                                    aanswer.setSelectionId(bselection.getId());
                                    answerRepository.save(aanswer);
                                }
                            }
                        }
                    }
                }
        );
        return bExam;
    }

    @Override
    public ExamPublishDto searchDetail(SearchExamDto searchExamDto) {
        Exam aExam = examRepository.findById(searchExamDto.getExamId()).get();
        List<Question> questions = examQuestionsRepository.findAllByExamId(aExam.getId());
        List<QuestionDto> questionDtoList = new ArrayList<QuestionDto>();
        questions.forEach(question -> {
            List<Selection> selections = selectionRepository.findAllByQuestionId(question.getId());
            List<Integer> answers = answerRepository.findAnswerByQuestionId(question.getId());
            List<String> selectionString = new ArrayList<String>();
            List<String> answerString = new ArrayList<String>();
            selections.forEach(selection -> {
                answers.forEach(answer -> {
                    if (answer == selection.getId()) {
                        answerString.add(selection.getContext());
                    }
                });
                selectionString.add(selection.getContext());
            });
            String[] selectionArray = selectionString.toArray(new String[selectionString.size()]);
            String[] answerArray = answerString.toArray(new String[answerString.size()]);
            System.out.println(selectionArray);
            System.out.println(answerArray);
            QuestionDto questionDto = new QuestionDto(question.getId(), question.getTitle(), question.getType(), question.getCourseName(),question.getScore(), selectionArray, answerArray);
            questionDtoList.add(questionDto);
        });
        List<Integer> students = examineeRepository.findByExamId(aExam.getId());
        String[] studentArray = new String[students.size()];
        for (int i = 0; i < students.size(); i++) {
            studentArray[i] = String.valueOf(students.get(i));
            System.out.println("studentArray[]" + i + "   " + studentArray[i]);
        }
        ExamPublishDto aEPD = new ExamPublishDto(aExam.getId(), aExam.getName(), aExam.getStatus(), studentArray, aExam.getStartTime(), aExam.getTeacherName(), aExam.getEndTime(), aExam.getLimitCome(), aExam.getLimitSubmit(), questionDtoList);
        return aEPD;
    }

    @Override
    public List<Exam> searchRough(SearchExamDto searchExamDto) {
        List<Exam> exams = new ArrayList<>();
        if (searchExamDto.getType().equals("all")) {
            if (searchExamDto.getIdentity().equals("教师")) {
                exams = examRepository.findAllByTeacherId(searchExamDto.getId());
            } else if (searchExamDto.getIdentity().equals("学生")) {
                exams = examRepository.findAllByStudentId(searchExamDto.getId());
            }

        } else {
            Exam aExam = examRepository.findById(searchExamDto.getExamId()).get();
            exams.add(aExam);
        }
        return exams;
    }

    @Override
    public List<StudentSelect> finishExam(FinishDto finishDto) {
        //todo 学生完成考卷
        int examId = finishDto.getExamId();
        String sno = finishDto.getSno();
        List<StudentSelectDto> s = finishDto.getContent();
        ObjectMapper mapper = new ObjectMapper();
        List<StudentSelectDto> ss = mapper.convertValue(s, new TypeReference<List<StudentSelectDto>>() {
        });
        System.out.println("回答:" + finishDto);
        System.out.println("复制的内容：" + ss);
        ss.forEach(item -> {
            int question_id = item.getQuestionId();
            String question_type = item.getQuestionType();
            List select_id = item.getSelectionId();
            String answerContent = null;
            if (!String.valueOf(select_id).equals("") && (question_type.equals("单选"))) {
                answerContent = answerRepository.searchContent((Integer) select_id.get(0));
            } else if ((question_type.equals("填空"))) {
                System.out.println("填空的内容：" + item.getAnswers().toString());
                answerContent = item.getAnswers().get(0);
            }
            String finalAnswerContent = answerContent;
            if (question_type.equals("单选") || question_type.equals("判断")) {
                StudentSelect select = new StudentSelect();
                select.setSno(sno);
                select.setExam_id(examId);
                select.setQuestion_id(question_id);
                select.setQuestion_type(question_type);
                select.setSelect_id((Integer) select_id.get(0));
                select.setAnswers(finalAnswerContent);
                select.setRight("");
                studentSelectRepository.save(select);
            } else if (question_type.equals("多选")) {
                select_id.forEach(f -> {
                    String context;
                    StudentSelect select = new StudentSelect();
                    select.setSno(sno);
                    select.setExam_id(examId);
                    select.setQuestion_id(question_id);
                    select.setQuestion_type(question_type);
                    select.setSelect_id((Integer) f);
                    context = answerRepository.searchContent((Integer) f);
                    select.setAnswers(context);
                    select.setRight("");
                    studentSelectRepository.save(select);
                });
            } else {
                StudentSelect select = new StudentSelect();
                select.setSno(sno);
                select.setExam_id(examId);
                select.setQuestion_id(question_id);
                select.setQuestion_type(question_type);
                select.setSelect_id(0);
                select.setAnswers(finalAnswerContent);
                select.setRight(questionBankRepository.findRightAnswer(question_id));
                studentSelectRepository.save(select);
            }
        });
        finishRepository.saveAll(examId, sno, "已完成");
        List<StudentSelect> map = studentSelectRepository.search(sno);
        return map;
    }

    @Override
    public List<Grade> correctExam(GradeDto gradeDto) {
        //todo 客观题自动批改，主观题老师给分
        //客观题
        String sno = gradeDto.getSno();
        int exam_id = gradeDto.getExam_id();
        float teaGrade = 0;
        List<StudentSelect> map = studentSelectRepository.search(sno);
        map.forEach(item -> {
            if (item.getQuestion_type().equals("单选") || item.getQuestion_type().equals("判断")) {
                int question_id = item.getQuestion_id();
                int select_id = item.getSelect_id();
                List right_id = answerRepository.findAnswerByQuestionId(question_id);
                if (select_id == (Integer) right_id.get(0)) {
                    grade_count = grade_count+questionBankRepository.findScore(question_id);
                }
            } else if (item.getQuestion_type().equals("多选")) {
                int question_id = item.getQuestion_id();
                List select_id = studentSelectRepository.findAllChoose(sno, question_id);
                List right_id = answerRepository.findAnswerByQuestionId(question_id);
                if (select_id.equals(right_id)) {
                    grade_count = grade_count+questionBankRepository.findScore(question_id);
                }
            }

        });
        List<Float> grade = gradeDto.getEach_point();
        for (int i = 0; i < grade.size(); i++) {
            teaGrade = teaGrade + grade.get(i);
        }
        if(examRepository.findInfo(exam_id).equals("互评")){
            float totalGrade = 0;
            List<Float> peerGrade = exchangeRepository.findGrade(sno);
            for(int i = 0;i<peerGrade.size();i++){
                totalGrade = totalGrade+peerGrade.get(i);
            }
            float averGrade = totalGrade/peerGrade.size();
            grade_count = (float) (grade_count+averGrade*0.4+teaGrade*0.6);
        }else{
            grade_count = grade_count+teaGrade;
        }
        Grade grade1 = new Grade();
        grade1.setSno(sno);
        grade1.setExam_id(exam_id);
        grade1.setFinal_grade(grade_count);
        gradeRepository.save(grade1);
        List<Grade> grades = gradeRepository.searchStudentGrade(sno,exam_id);
        grade_count = 0;
        return grades;
    }

    @Override
    public List<StudentSelect> checkExam(GradeDto gradeDto) {
        int exam_id = gradeDto.getExam_id();
        System.out.println("id："+exam_id);
        List<StudentSelect> map = studentSelectRepository.findAnswers(exam_id);
        System.out.println("批改："+map);
        return map;
    }
    @Override
    public List<StudentSelect> exchangeExam(ExchangeDto exchangeDto) {
        String sno = exchangeDto.getSno();
        int i = 0;
        int exam_id = exchangeDto.getExam_id();
        List<Integer> StuList = examineeRepository.findAllByExamId(exam_id,Integer.parseInt(sno));
        System.out.println("stulist:"+StuList);
        List<Integer> newList = new ArrayList<>();
        Random rd = new Random();
        while (newList.size()<=2){
            int temp = rd.nextInt(StuList.size());
            if(examineeRepository.findCountBySno(Integer.parseInt(sno))<2){
                newList.add(StuList.get(temp));
            }
            i++;
        }
        List<StudentSelect> map = studentSelectRepository.searchOthers(exam_id,newList.get(0).toString(),newList.get(1).toString());
        System.out.println("map"+map);
        int flag1 = examineeRepository.findCountBySno(newList.get(0));
        int flag2 = examineeRepository.findCountBySno(newList.get(1));
        if(flag1==0&&flag2==0){
            examineeRepository.updateCheck(1,newList.get(0));
            examineeRepository.updateCheck(1,newList.get(1));
        }else if(flag1==1&&flag2==0){
            examineeRepository.updateCheck(2,newList.get(0));
            examineeRepository.updateCheck(1,newList.get(1));
        }else{
            examineeRepository.updateCheck(2,newList.get(1));
            examineeRepository.updateCheck(1,newList.get(0));
        }
        return map;
    }

    @Override
    public List<Exchange_paper> peerEvaluate(ExchangeDto exchangeDto) {
        System.out.println("exchange:"+exchangeDto);
        List<ExchangeDto> paper = new ArrayList<>();
        List<List<Float>> totalGrades = new ArrayList<>();
        List<String> snoList = new ArrayList<>();
        int exam_id = exchangeDto.getExam_id();
        String sno = exchangeDto.getSno();
            List<peerDto> list = exchangeDto.getDetail();
            System.out.println("list:"+list);
            list.forEach(e->{
                Exchange_paper exchange_paper = new Exchange_paper();
                exchange_paper.setExam_id(exam_id);
                exchange_paper.setSno(sno);
                exchange_paper.setSno_corrected(e.getSno_corrected());
                snoList.add(e.getSno_corrected());
                List<Float> gg = new ArrayList<>();
                List<DetailDto> detailDtoList = e.getDetails();
                detailDtoList.forEach(a->{
                    float grades = a.getGrades();
                    gg.add(grades);
                    exchangeRepository.save(exchange_paper);
                });
                totalGrades.add(gg);
            });
        for(int i = 0;i<totalGrades.size();i++){
            float grade=0;
            for(int j = 0;j<totalGrades.get(i).size();j++){
                grade = grade+totalGrades.get(i).get(j);
            }
            exchangeRepository.updateGrade(grade,snoList.get(i));
        }
        List<Exchange_paper> maps = exchangeRepository.searchGrade(sno);
        System.out.println("maps:"+maps);
        return maps;
    }

    @Override
    public void deleteExam(ExchangeDto exchangeDto) {
        int exam_id = exchangeDto.getExam_id();
        studentSelectRepository.deleteByExamId(exam_id);
        gradeRepository.deleteByExamId(exam_id);
        finishRepository.deleteByExamId(exam_id);
        exchangeRepository.deleteByExamId(exam_id);
        examineeRepository.deleteByExamId(exam_id);
        examQuestionsRepository.deleteByExamId(exam_id);
        examRepository.deleteByExamId(exam_id);
    }
}
