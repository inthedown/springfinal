package com.zucc.Service;

import com.zucc.Entity.*;
import com.zucc.Form.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public interface ExamService {
    Exam publish(ExamPublishDto examPublishDto);

    ExamPublishDto searchDetail(SearchExamDto searchExamDto);

    List<Exam> searchRough(SearchExamDto searchExamDto);

    List<StudentSelect> finishExam(FinishDto finishDto);

    List<Grade> correctExam(GradeDto gradeDto);
    List<StudentSelect> checkExam(GradeDto gradeDto);

    List<StudentSelect> exchangeExam(ExchangeDto exchangeDto);

    List<Exchange_paper> peerEvaluate(ExchangeDto exchangeDto);

    void deleteExam(ExchangeDto exchangeDto);
}
