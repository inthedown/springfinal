package com.zucc.Entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "Examinee", schema = "javaeee")
public class Examinee {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Basic
    @Column(name = "examId")
    private int examId;
    @Basic
    @Column(name = "studentId")
    private int studentId;
    @Basic
    @Column(name = "count_num")
    private int count;
}
