package com.zucc.Entity;

import com.zucc.Form.peerDto;
import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Data
@Table(name = "Exchange_paper", schema = "javaeee")
public class Exchange_paper {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Basic
    @Column(name = "exam_id")
    private int exam_id;
    @Basic
    @Column(name = "sno")
    private String sno;
    @Basic
    @Column(name = "sno_corrected")
    private String sno_corrected;
    @Basic
    @Column(name = "grade")
    private float grade;
    @Transient
    private List<peerDto> details;
}
