package com.zucc.Entity;

import lombok.Data;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
@Table(name = "StudentSelect", schema = "javaeee")
public class StudentSelect {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Basic
    @Column(name = "sno")
    private String sno;
    @Basic
    @Column(name = "examId")
    private int exam_id;
    @Basic
    @Column(name = "questionId")
    private int question_id;
    @Basic
    @Column(name = "questionType")
    private String question_type;
    @Basic
    @Column(name = "selectId")
    private int select_id;
    @Basic
    @Column(name = "answers")
    private String answers;

    @Basic
    @Column(name = "right_answers")
    private String right;
    @Transient
    private List answer_content;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String getSno() {
        return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public int getExam_id() {
        return exam_id;
    }

    public void setExam_id(int exam_id) {
        this.exam_id = exam_id;
    }

    public int getQuestion_id() {
        return question_id;
    }

    public void setQuestion_id(int question_id) {
        this.question_id = question_id;
    }

    public String getQuestion_type() {
        return question_type;
    }

    public void setQuestion_type(String question_type) {
        this.question_type = question_type;
    }

    public int getSelect_id() {
        return select_id;
    }

    public void setSelect_id(int select_id) {
        this.select_id = select_id;
    }

    public String getAnswers() {
        return answers;
    }

    public void setAnswers(String answers) {
        this.answers = answers;
    }

    public String getRight() {
        return right;
    }

    public void setRight(String right) {
        this.right = right;
    }
}
