package com.zucc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeparationOfTeachingAndTestingApplicationTests {

    @Test
    void contextLoads() {
    }

}
