package com.zucc.Form;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Data
public class GradeDto implements Serializable {
    private int id;
    private String sno;
    private int exam_id;
    private List<Integer> each_point;
    private int final_grade;
}
