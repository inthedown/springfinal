package com.zucc.Form;

import lombok.Data;

import java.io.Serializable;

@Data
public class TeacherDto implements Serializable {
    private int t_id;//老师的编号
    private String tno;//老师的工号
    private String name;//老师姓名
    private String pwd;//密码
    private String new_pwd;//新密码
}
