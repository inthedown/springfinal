package com.zucc.Form;

import lombok.Data;

import java.io.Serializable;

@Data
public class StudentDto implements Serializable {
    private int s_id;//学生的编号
    private String sno;//学生学号
    private String name;//学生姓名
    private String pwd;//密码
    private String new_pwd;//新密码
    private String course_name;//学生对应的课程
}
