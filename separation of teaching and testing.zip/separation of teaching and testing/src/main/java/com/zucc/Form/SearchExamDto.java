package com.zucc.Form;

import lombok.Data;

@Data
public class SearchExamDto {
    private final int id;
    private final String identity;
    private final String type;
    private final int examId;
}
