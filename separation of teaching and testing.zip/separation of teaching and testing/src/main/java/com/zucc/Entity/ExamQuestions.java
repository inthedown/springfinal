package com.zucc.Entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "ExamQuestions", schema = "javaeee")
public class ExamQuestions {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Basic
    @Column(name = "examId")
    private int examId;
    @Basic
    @Column(name = "questionId")
    private int questionId;
}
