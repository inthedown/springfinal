package com.zucc.Entity;

import com.zucc.Form.QuestionDto;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
@Getter
@Setter
@SqlResultSetMapping(
        name = "question",
        entities = {
                @EntityResult(
                        entityClass = Question.class, // 当前类名
                        fields = {
                                @FieldResult(name = "id", column = "id"),
                                @FieldResult(name = "courseName", column = "course_name"),
                                @FieldResult(name = "title", column = "title"),
                                @FieldResult(name = "type", column = "type")

                        }
                )
        }
)
@Data
@Entity
@Table(name = "Question", schema = "javaeee")
public class Question {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Basic
    @Column(name = "title")
    private String title;
    @Basic
    @Column(name = "type")
    private String type;
    @Basic
    @Column(name = "courseName")
    private String courseName;
}
