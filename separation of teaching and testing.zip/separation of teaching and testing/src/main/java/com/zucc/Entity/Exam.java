package com.zucc.Entity;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Data
@Entity
@Table(name = "Exam", schema = "javaeee")
public class Exam {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Basic
    @Column(name = "name")
    private String name;
    @Basic
    @Column(name = "status")
    private String status;
    @Basic
    @Column(name = "teacherName")
    private String teacherName;
    @Basic
    @Column(name = "startTime")
    private Timestamp startTime;
    @Basic
    @Column(name = "endTime")
    private Timestamp endTime;
    @Basic
    @Column(name = "limitCome")
    private Timestamp limitCome;
    @Basic
    @Column(name = "limitSubmit")
    private Timestamp limitSubmit;

}
