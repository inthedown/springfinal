package com.zucc.Controller;

import com.zucc.Entity.Exam;
import com.zucc.Entity.Grade;
import com.zucc.Entity.Question;
import com.zucc.Entity.StudentSelect;
import com.zucc.Form.*;
import com.zucc.Result.ExceptionMsg;
import com.zucc.Result.ResponseData;
import com.zucc.Service.ExamService;
import com.zucc.Service.StudentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("exam")
public class ExamController {
    private final Logger logger = LoggerFactory.getLogger(ExamController.class);
    @Autowired
    private ExamService examService;

    @RequestMapping(value = "publish", method =  RequestMethod.POST)
    @ResponseBody
    public ResponseData publish(@RequestBody ExamPublishDto examPublishDto){
        //todo 发布考试
        examService.publish(examPublishDto);
        return  new ResponseData(ExceptionMsg.SUCCESS,1);
    }
    @RequestMapping(value = "make", method =  RequestMethod.POST)
    @ResponseBody
    public ResponseData make(@RequestBody QuestionDto questionDto){
        //todo 学生完成考试
        return  new ResponseData(ExceptionMsg.SUCCESS,1);
    }
    @RequestMapping(value = "search_rough", method =  RequestMethod.POST)
    @ResponseBody
    public ResponseData searchRough(@RequestBody SearchExamDto searchExamDto){
       List<Exam> exams= examService.searchRough(searchExamDto);
        return  new ResponseData(ExceptionMsg.SUCCESS,exams);
    }
    @RequestMapping(value = "search_detail", method =  RequestMethod.POST)
    @ResponseBody
    public ResponseData searchDetail(@RequestBody SearchExamDto searchExamDto){
        ExamPublishDto aEPD= examService.searchDetail(searchExamDto);
        return  new ResponseData(ExceptionMsg.SUCCESS,aEPD);
    }
    @RequestMapping(value = "finish", method =  RequestMethod.POST)
    @ResponseBody
    public ResponseData finishExam(@RequestBody FinishDto finishDto){
        List<StudentSelect> map= examService.finishExam(finishDto);
        return  new ResponseData(ExceptionMsg.SUCCESS,map);
    }
    @RequestMapping(value = "correct", method =  RequestMethod.POST)
    @ResponseBody
    public ResponseData correct(@RequestBody GradeDto gradeDto){
        //todo 教师批改考试
        List<Grade> map = examService.checkExam(gradeDto);
        return  new ResponseData(ExceptionMsg.SUCCESS,map);
    }
}
