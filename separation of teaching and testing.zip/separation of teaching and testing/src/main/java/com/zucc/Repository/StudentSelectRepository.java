package com.zucc.Repository;

import com.zucc.Entity.Selection;
import com.zucc.Entity.StudentSelect;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;

public interface StudentSelectRepository extends JpaRepository<StudentSelect,Integer> {
    @Query(value = "select * from Student_Select where sno=:sno",nativeQuery = true)
    List<StudentSelect> search(String sno);
    @Query(value = "select select_id from Student_Select where sno=:sno and question_id=:id",nativeQuery = true)
    List<Integer> findAllChoose(String sno, int id);
}
