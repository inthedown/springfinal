package com.zucc.Repository;

import com.zucc.Entity.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface GradeRepository extends JpaRepository<Grade,Integer> {
    @Query(value = "select * from grade where sno=:sno and exam_id=:id",nativeQuery = true)
    List<Grade> searchStudentGrade(String sno, int id);
}
