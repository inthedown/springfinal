package com.zucc.Repository;

import com.zucc.Entity.Examinee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ExamineeRepository extends JpaRepository<Examinee,Integer> {
    @Query(value="select * from examinee where exam_id=:id",nativeQuery = true)
    List<Integer> findAllByExamId(int id);
}
