package com.zucc.Repository;

import com.zucc.Entity.ExamQuestions;
import com.zucc.Entity.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ExamQuestionsRepository extends JpaRepository<ExamQuestions,Integer> {
//    @Query(value="select * from question where id in( select question_id from exam_questions where exam_id=:id)",nativeQuery = true)
@Query(value="from Question where id in( select questionId from ExamQuestions where examId=:id)")
    List<Question> findAllByExamId(int id);
}
