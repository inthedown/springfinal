package com.zucc.Repository;

import com.zucc.Entity.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ExamRepository extends JpaRepository<Exam,Integer> {
    @Query(value="SELECT * from exam where teacher_name in (select tea_name from teacher where t_id=:id)",nativeQuery = true)
    List<Exam> findAllByTeacherId(int id);
    @Query(value="SELECT * from exam where id in (select exam_id from examinee where student_id=:id)",nativeQuery = true)
    List<Exam> findAllByStudentId(int id);
}
