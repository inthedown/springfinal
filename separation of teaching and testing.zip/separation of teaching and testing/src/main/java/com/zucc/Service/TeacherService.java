package com.zucc.Service;

import com.zucc.Exception.EchoServiceException;
import com.zucc.Form.TeacherDto;

import java.util.Map;

public interface TeacherService {
    /**
     * 注册
     * @param teacherDto
     * @return
     * @throws EchoServiceException
     */
    boolean register(TeacherDto teacherDto) throws EchoServiceException;
    /**
     * 密码登录
     * @param teacher
     * @return
     * @throws EchoServiceException
     */
    boolean login(TeacherDto teacherDto) throws EchoServiceException;
    /**
     * 修改密码
     * @param teacher
     * @return
     * @throws EchoServiceException
     */
    boolean modifyPwd(TeacherDto teacherDto) throws EchoServiceException;
    /**
     * 删除
     * @param teacher
     * @return
     * @throws EchoServiceException
     */
    boolean deleteTeacher(TeacherDto teacherDto) throws EchoServiceException;
}
