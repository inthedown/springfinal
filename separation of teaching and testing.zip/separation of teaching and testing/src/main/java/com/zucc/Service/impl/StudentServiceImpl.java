package com.zucc.Service.impl;

import com.zucc.Entity.Student;
import com.zucc.Exception.EchoServiceException;
import com.zucc.Form.StudentDto;
import com.zucc.Repository.CourseRepository;
import com.zucc.Repository.StudentRepository;
import com.zucc.Service.StudentService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class StudentServiceImpl implements StudentService {
    public List<Student> students;//所有学生
    @Resource
    private StudentRepository studentrepository;
    @Autowired
    private CourseRepository courseRepository;
    @Override
    public boolean register(StudentDto studentDto) throws EchoServiceException {
        Student aStudent = new Student();
        BeanUtils.copyProperties(studentDto, aStudent);
        System.out.println("内容1："+aStudent);
        System.out.println("内容2："+studentDto);
        String sno = studentDto.getSno();
        String name = studentDto.getName();
        String pwd = studentDto.getPwd();
        String course = studentDto.getCourse_name();
        if((studentrepository.searchPwd(name)==null)&&(courseRepository.findId(course)!=null)){
            aStudent.setName(name);
            aStudent.setPwd(pwd);
            aStudent.setSno(sno);
            studentrepository.save(aStudent);
            studentrepository.saveCourse(sno,name,course);
            return true;
        }else{
            return false;
        }
    }
    @Override
    public boolean login(StudentDto studentDto) throws EchoServiceException{
        String sno = studentDto.getSno();
        String pwd = studentDto.getPwd();
        if (studentrepository.searchPwd(sno) != null) {
            if (studentrepository.searchPwd(sno).equals(pwd)) return true;
            else return false;
        } else {
            return false;
        }
    }
    @Override
    public boolean modifyPwd(StudentDto studentDto) throws EchoServiceException{
        String sno = studentDto.getSno();
        String pwd = studentDto.getPwd();
        String new_pwd = studentDto.getNew_pwd();
        if (studentrepository.searchPwd(sno) != null) {
            if (studentrepository.searchPwd(sno).equals(pwd)) {
                studentrepository.changePwd(sno,new_pwd);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    @Override
    public boolean modifyInfo(StudentDto studentDto) throws EchoServiceException{
        String sno = studentDto.getSno();
        String course = studentDto.getCourse_name();
        studentrepository.changeInfo(course, sno);
        return  true;
    }
    @Override
    public boolean delete(StudentDto studentDto) throws EchoServiceException{
        String sno = studentDto.getSno();
        if (studentrepository.searchPwd(sno)!= null) {
            studentrepository.deleteBySno(sno);
            studentrepository.deleteAllBySno(sno);
            return  true;
        } else {
            return  false;
        }
    }
}
