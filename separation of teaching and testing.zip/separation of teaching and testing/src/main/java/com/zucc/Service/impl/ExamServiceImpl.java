package com.zucc.Service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zucc.Entity.*;
import com.zucc.Form.*;
import com.zucc.Repository.*;
import com.zucc.Service.ExamService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
@Service
public class ExamServiceImpl implements ExamService {
    @Autowired
    private ExamRepository examRepository;
    @Autowired
    private ExamineeRepository examineeRepository;
    @Autowired
    private ExamQuestionsRepository examQuestionsRepository;
    @Autowired
    private QuestionBankRepository questionBankRepository;
    @Autowired
    private SelectionRepository selectionRepository;
    @Autowired
    private AnswerRepository answerRepository;
    @Autowired
    private StudentSelectRepository studentSelectRepository;
    @Autowired
    private FinishRepository finishRepository;
    @Autowired
    private GradeRepository gradeRepository;
    private int grade_count = 0;
    @Override
    public Exam publish(ExamPublishDto examPublishDto) {
        //考卷插入
        Exam aExam = examPublishDto.convert(examPublishDto);
        System.out.println(aExam);
        Exam bExam= examRepository.save(aExam);
        String[] examinees=examPublishDto.getExaminees();
        //参考人员插入
        for (String examine : examinees) {
            if( Pattern.compile("^-?[1-9]\\d*$").matcher(examine).find()){
                Examinee aExaminee=new Examinee();
                aExaminee.setExamId(bExam.getId());
                aExaminee.setStudentId(Integer.valueOf(examine));
                examineeRepository.save(aExaminee);
            }
        }
        //考题插入题库
        List<QuestionDto> questionDtoList=examPublishDto.getQuestions();
        questionDtoList.forEach(questionDto -> {
            System.out.println(questionDto);
            Question aquestion = new Question();
            aquestion.setCourseName(questionDto.getCourseName());
            aquestion.setTitle(questionDto.getTitle());
            aquestion.setType(questionDto.getQuestionType());
            Question bquestion=questionBankRepository.save(aquestion);
            int questionId = bquestion.getId();
            ExamQuestions aEQ = new ExamQuestions();
            aEQ.setExamId(bExam.getId());
            aEQ.setQuestionId(questionId);
            examQuestionsRepository.save(aEQ);
            String type = questionDto.getQuestionType();
            if(type.equals("单选")||type.equals("填空")||type.equals("判断")){
                String[] selections=questionDto.getSelections();
                String[] answers = questionDto.getAnswer();
                for (String selection : selections) {
                    Selection aselection=new Selection();
                    aselection.setQuestionId(questionId);
                    aselection.setContext(selection);
                    Selection bselection=selectionRepository.save(aselection);
                    if(answers!=null){
                        if(selection.equals(answers[0])){
                            Answer aanswer=new Answer();
                            aanswer.setQuestionId(questionId);
                            aanswer.setSelectionId(bselection.getId());
                            answerRepository.save(aanswer);
                        }
                    }

                }
            }else if(type.equals("多选")){
                String[] selections=questionDto.getSelections();
                String[] answers = questionDto.getAnswer();
                for (String selection : selections) {
                    Selection aselection=new Selection();
                    aselection.setQuestionId(questionId);
                    aselection.setContext(selection);
                    Selection bselection=selectionRepository.save(aselection);
                    for(String answer :answers) {
                        if (selection.equals(answer)) {
                            Answer aanswer = new Answer();
                            aanswer.setQuestionId(questionId);
                            aanswer.setSelectionId(bselection.getId());
                            answerRepository.save(aanswer);
                        }
                    }
                }
            }
                }
        );
return bExam;
    }

    @Override
    public ExamPublishDto searchDetail(SearchExamDto searchExamDto) {
        Exam aExam= examRepository.findById(searchExamDto.getExamId()).get();
        List<Question> questions=examQuestionsRepository.findAllByExamId(aExam.getId());
        List<QuestionDto> questionDtoList=new ArrayList<QuestionDto>();
        questions.forEach(question -> {
            List<Selection> selections=selectionRepository.findAllByQuestionId(question.getId());
            List<Integer> answers=answerRepository.findAnswerByQuestionId(question.getId());
            List<String> selectionString=new ArrayList<String>();
            List<String> answerString=new ArrayList<String>();
            selections.forEach(selection ->{
                answers.forEach(answer ->{
                    if(answer==selection.getId()){
                        answerString.add(selection.getContext());
                    }
                });
                selectionString.add(selection.getContext());
            });
            String[] selectionArray=selectionString.toArray(new String[selectionString.size()]);
            String[] answerArray=answerString.toArray(new String[answerString.size()]);
            System.out.println(selectionArray);
            System.out.println(answerArray);
            QuestionDto questionDto=new QuestionDto(question.getId(),question.getTitle(),question.getType(),question.getCourseName(),selectionArray,answerArray);
            questionDtoList.add(questionDto);
        });
        List<Integer> students=examineeRepository.findAllByExamId(aExam.getId());
        String[] studentArray=students.toArray(new String[students.size()]);
        ExamPublishDto aEPD=new ExamPublishDto(aExam.getId(),aExam.getName(),aExam.getStatus(),studentArray,aExam.getStartTime(),aExam.getTeacherName(),aExam.getEndTime(),aExam.getLimitCome(),aExam.getLimitSubmit(),questionDtoList );
        return  aEPD;
    }

    @Override
    public List<Exam> searchRough(SearchExamDto searchExamDto) {
        List<Exam> exams=new ArrayList<>();
        if(searchExamDto.getType().equals("all")){
            if(searchExamDto.getIdentity().equals("教师")){
                exams= examRepository.findAllByTeacherId(searchExamDto.getId());
            }else if(searchExamDto.getIdentity().equals("学生")){
                exams= examRepository.findAllByStudentId(searchExamDto.getId());
            }

        }else{
            Exam aExam= examRepository.findById(searchExamDto.getExamId()).get();
            exams.add(aExam);
        }
        return exams;
    }

    @Override
    public List<StudentSelect> finishExam(FinishDto finishDto) {
        //todo 学生完成考卷
        int examId = finishDto.getExamId();
        String sno = finishDto.getSno();
        List<StudentSelectDto> s = finishDto.getContent();
        ObjectMapper mapper = new ObjectMapper();
        List<StudentSelectDto> ss = mapper.convertValue(s, new TypeReference<List<StudentSelectDto>>() {
        });
        System.out.println("回答:"+finishDto);
        System.out.println("复制的内容："+ss);
        ss.forEach(item->{
            int question_id = item.getQuestionId();
            String question_type = item.getQuestionType();
            List select_id = item.getSelectionId();
            String answerContent = null;
            if(!String.valueOf(select_id).equals("")&&(question_type.equals("单选"))){
                answerContent = answerRepository.searchContent((Integer) select_id.get(0));
            }else if((question_type.equals("填空"))){
                System.out.println("填空的内容："+item.getAnswers().toString());
                answerContent = item.getAnswers().get(0);
            }
            String finalAnswerContent = answerContent;
            if(question_type.equals("单选")||question_type.equals("判断")){
                StudentSelect select = new StudentSelect();
                select.setSno(sno);
                select.setExam_id(examId);
                select.setQuestion_id(question_id);
                select.setQuestion_type(question_type);
                select.setSelect_id((Integer) select_id.get(0));
                select.setAnswers(finalAnswerContent);
                studentSelectRepository.save(select);
            }else if(question_type.equals("多选")){
                select_id.forEach(f->{
                    String context;
                    StudentSelect select = new StudentSelect();
                    select.setSno(sno);
                    select.setExam_id(examId);
                    select.setQuestion_id(question_id);
                    select.setQuestion_type(question_type);
                    select.setSelect_id((Integer) f);
                    context = answerRepository.searchContent((Integer) f);
                    select.setAnswers(context);
                    studentSelectRepository.save(select);
                });
            }else{
                StudentSelect select = new StudentSelect();
                select.setSno(sno);
                select.setExam_id(examId);
                select.setQuestion_id(question_id);
                select.setQuestion_type(question_type);
                select.setSelect_id(0);
                select.setAnswers(finalAnswerContent);
                studentSelectRepository.save(select);
            }
        });
        finishRepository.saveAll(examId,sno,"已完成");
        List<StudentSelect> map = studentSelectRepository.search(sno);
        return map;
    }

    @Override
    public List<Grade> checkExam(GradeDto gradeDto) {
        //todo 客观题自动批改，主观题老师给分
        //客观题
        String sno = gradeDto.getSno();
        int exam_id = gradeDto.getExam_id();
        List<StudentSelect> map = studentSelectRepository.search(sno);
        map.forEach(item->{
            if(item.getQuestion_type().equals("单选")||item.getQuestion_type().equals("判断")){
                int question_id = item.getQuestion_id();
                int select_id = item.getSelect_id();
                List right_id = answerRepository.findAnswerByQuestionId(question_id);
                if(select_id==(Integer) right_id.get(0)){
                    grade_count++;
                }
            }else if(item.getQuestion_type().equals("多选")){
                int question_id = item.getQuestion_id();
                List select_id = studentSelectRepository.findAllChoose(sno,question_id);
                List right_id = answerRepository.findAnswerByQuestionId(question_id);
                if(select_id.equals(right_id)){
                    grade_count++;
                }
            }

        });
        List<Integer> grade = gradeDto.getEach_point();
        for(int i = 0 ;i<grade.size();i++){
            grade_count=grade_count+grade.get(i);
        }
        Grade grade1 = new Grade();
        grade1.setSno(sno);
        grade1.setExam_id(exam_id);
        grade1.setFinal_grade(grade_count);
        gradeRepository.save(grade1);
        List<Grade> grades = gradeRepository.searchStudentGrade(sno,exam_id);
        //finishRepository.checkAll(sno,"已批改");
        grade_count = 0;
        return grades;
    }
}
