package com.zucc.Service;

import com.zucc.Entity.Answer;
import com.zucc.Entity.Exam;
import com.zucc.Entity.Grade;
import com.zucc.Entity.StudentSelect;
import com.zucc.Form.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public interface ExamService {
    Exam publish(ExamPublishDto examPublishDto);

    ExamPublishDto searchDetail(SearchExamDto searchExamDto);

    List<Exam> searchRough(SearchExamDto searchExamDto);

    List<StudentSelect> finishExam(FinishDto finishDto);

    List<Grade> checkExam(GradeDto gradeDto);
}
